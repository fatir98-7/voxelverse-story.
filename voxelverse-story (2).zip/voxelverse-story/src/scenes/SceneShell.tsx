import React from 'react';
import {interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {BoxView, clamp, easeInOut, lerp, mulberry32, proj, sortBoxes} from '../voxel/iso';
import {SceneOut} from './kit';
import {THEMES} from './themes';
import {SceneDef, Timeline} from '../types';

export const WIDTH = 1080;
export const HEIGHT = 1920;
const CX = WIDTH / 2;
const CY = 900;

const ridgePath = (base: number, amp: number, seed: number) => {
  const pts: string[] = [`0,${HEIGHT}`];
  for (let x = 0; x <= WIDTH + 40; x += 40) {
    const n = Math.sin(x * 0.006 + seed) * 0.5 + Math.sin(x * 0.0173 + seed * 2.1) * 0.3 + Math.sin(x * 0.041 + seed * 3.3) * 0.2;
    pts.push(`${x},${(base - amp * (n * 0.5 + 0.5)).toFixed(1)}`);
  }
  pts.push(`${WIDTH + 40},${HEIGHT}`);
  return pts.join(' ');
};

const Sky: React.FC<{o: SceneOut; t: number}> = ({o, t}) => {
  const s = o.sky;
  const rnd = mulberry32(99);
  return (
    <g>
      <rect width={WIDTH} height={HEIGHT} fill="url(#sky)" />
      {s.sun && (
        <g>
          <circle cx={s.sun.x} cy={s.sun.y} r={s.sun.r * 3.2} fill="url(#sunGlow)" />
          <circle cx={s.sun.x} cy={s.sun.y} r={s.sun.r} fill={s.sun.color} />
        </g>
      )}
      {s.moon && (
        <g>
          <circle cx={800} cy={330} r={260} fill="url(#moonGlow)" />
          <circle cx={800} cy={330} r={74} fill="#f3f1de" />
          <circle cx={780} cy={315} r={14} fill="#dcd9c0" />
          <circle cx={822} cy={350} r={10} fill="#dcd9c0" />
        </g>
      )}
      {s.stars &&
        Array.from({length: 90}).map((_, i) => {
          const x = rnd() * WIDTH;
          const y = rnd() * 760;
          const r = 1.2 + rnd() * 2.2;
          const tw = 0.45 + 0.55 * Math.sin(t * (1 + rnd() * 2.5) + i);
          return <rect key={i} x={x} y={y} width={r * 1.6} height={r * 1.6} fill="#ffffff" opacity={tw} />;
        })}
      {s.ridges?.map((r, i) => (
        <polygon key={i} points={ridgePath(r.base, r.amp, r.seed)} fill={r.color} />
      ))}
    </g>
  );
};

const Fx: React.FC<{o: SceneOut; t: number; amp: number}> = ({o, t, amp}) => {
  const f = o.fx;
  const out: React.ReactNode[] = [];
  if (f.rays) {
    for (let i = 0; i < 4; i++) {
      const op = 0.1 + 0.05 * Math.sin(t * 0.8 + i * 1.7) + amp * 0.05;
      const x0 = 520 + i * 150;
      out.push(<polygon key={`ray${i}`} points={`${x0},0 ${x0 + 90},0 ${x0 - 560},1500 ${x0 - 760},1500`} fill="url(#rayGrad)" opacity={op} />);
    }
  }
  if (f.pollen) {
    const r = mulberry32(5);
    for (let i = 0; i < 36; i++) {
      const bx = r() * WIDTH;
      const by = r() * HEIGHT;
      const sp = 14 + r() * 22;
      const x = (bx + Math.sin(t * 0.7 + i) * 40 + t * 8) % WIDTH;
      const y = (((by - t * sp) % HEIGHT) + HEIGHT) % HEIGHT;
      out.push(<circle key={`p${i}`} cx={x} cy={y} r={2 + r() * 3} fill="#fffbe0" opacity={0.35 + 0.35 * Math.sin(t * 2 + i)} />);
    }
  }
  if (f.fireflies) {
    const r = mulberry32(8);
    for (let i = 0; i < 22; i++) {
      const bx = 100 + r() * 880;
      const by = 600 + r() * 800;
      const x = bx + Math.sin(t * (0.5 + r()) + i) * 60;
      const y = by + Math.cos(t * (0.4 + r()) + i * 2) * 50;
      const a = clamp(0.5 + 0.5 * Math.sin(t * 2.5 + i * 1.3)) * (0.6 + amp * 0.4);
      out.push(<circle key={`ff${i}`} cx={x} cy={y} r={14} fill="url(#ffGlow)" opacity={a} />);
      out.push(<circle key={`fd${i}`} cx={x} cy={y} r={3.2} fill="#fff6a8" opacity={a} />);
    }
  }
  if (f.birds) {
    for (let i = 0; i < 3; i++) {
      const sp = 70 + i * 18;
      const x = ((t * sp + i * 380) % 1500) - 200;
      const y = 300 + i * 90 + Math.sin(t * 1.4 + i) * 20;
      const fl = Math.sin(t * 9 + i * 2) * 10;
      out.push(<polyline key={`b${i}`} points={`${x - 22},${y - fl} ${x},${y + 4} ${x + 22},${y - fl}`} fill="none" stroke="#2c3440" strokeWidth={4} strokeLinecap="round" strokeLinejoin="round" opacity={0.7} />);
    }
  }
  if (f.rain) {
    const r = mulberry32(12);
    for (let i = 0; i < 130; i++) {
      const x0 = r() * 1400 - 150;
      const sp = 1500 + r() * 900;
      const len = 40 + r() * 70;
      const y = (((r() * 2100 + t * sp) % 2100) + 2100) % 2100 - 100;
      out.push(<line key={`r${i}`} x1={x0} y1={y} x2={x0 - len * 0.22} y2={y + len} stroke="#cfe0ff" strokeWidth={2.4} opacity={0.38} strokeLinecap="round" />);
    }
  }
  return <g>{out}</g>;
};

type Props = {theme: SceneDef['theme']; sceneStart: number; sceneEnd: number; timeline: Timeline; seed: number; fadeFrames: number};

export const SceneShell: React.FC<Props> = ({theme, sceneStart, sceneEnd, timeline, seed, fadeFrames}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const gt = sceneStart + t;
  const d = sceneEnd - sceneStart;

  const ei = Math.min(timeline.env.length - 1, Math.max(0, Math.round(gt * timeline.envFps)));
  const amp = timeline.env[ei] ?? 0;

  const o = THEMES[theme]({t, d, amp, seed});

  // denyut kamera tiap potongan subtitle / awal kalimat
  let beat = 0;
  for (const b of timeline.beats) {
    if (b <= gt) beat = gt - b;
    else break;
  }
  const pulse = Math.exp(-beat * 7) * 0.016 + amp * 0.006;
  const zoom = lerp(o.zoom[0], o.zoom[1], easeInOut(clamp(t / d))) + pulse;
  const [fx, fy] = proj(o.focus[0], o.focus[1], o.focus[2]);
  const bob = Math.sin(t * 1.1) * 9;
  const panX = Math.sin(t * 0.35) * 18;

  const sorted = sortBoxes(o.boxes);
  const fade = fadeFrames > 0 ? interpolate(frame, [0, fadeFrames], [0, 1], {extrapolateRight: 'clamp'}) : 1;
  const [cx0, cy0] = proj(6.5, 6.5, -6);

  return (
    <div style={{position: 'absolute', inset: 0, opacity: fade}}>
      <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`} style={{position: 'absolute', inset: 0}}>
        <defs>
          <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={o.sky.top} />
            <stop offset="0.5" stopColor={o.sky.mid} />
            <stop offset="1" stopColor={o.sky.bottom} />
          </linearGradient>
          <radialGradient id="sunGlow">
            <stop offset="0" stopColor="#fff4c8" stopOpacity={0.55 + amp * 0.2} />
            <stop offset="1" stopColor="#fff4c8" stopOpacity={0} />
          </radialGradient>
          <radialGradient id="moonGlow">
            <stop offset="0" stopColor="#dfe6ff" stopOpacity={0.4} />
            <stop offset="1" stopColor="#dfe6ff" stopOpacity={0} />
          </radialGradient>
          <radialGradient id="ffGlow">
            <stop offset="0" stopColor="#fff6a8" stopOpacity={0.9} />
            <stop offset="1" stopColor="#fff6a8" stopOpacity={0} />
          </radialGradient>
          <radialGradient id="shadow">
            <stop offset="0" stopColor="#000" stopOpacity={0.35} />
            <stop offset="1" stopColor="#000" stopOpacity={0} />
          </radialGradient>
          <linearGradient id="rayGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#fff2c2" stopOpacity={0.9} />
            <stop offset="1" stopColor="#fff2c2" stopOpacity={0} />
          </linearGradient>
          <radialGradient id="vig" cx="0.5" cy="0.46" r="0.75">
            <stop offset="0.55" stopColor="#000" stopOpacity={0} />
            <stop offset="1" stopColor="#000" stopOpacity={0.5} />
          </radialGradient>
          <linearGradient id="capShade" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#000" stopOpacity={0} />
            <stop offset="1" stopColor="#000" stopOpacity={0.6} />
          </linearGradient>
          {o.glows.map((g, i) => (
            <radialGradient id={`gl${i}`} key={i}>
              <stop offset="0" stopColor={g.color} stopOpacity={1} />
              <stop offset="0.4" stopColor={g.color} stopOpacity={0.35} />
              <stop offset="1" stopColor={g.color} stopOpacity={0} />
            </radialGradient>
          ))}
        </defs>

        <Sky o={o} t={t} />

        <g transform={`translate(${CX + panX} ${CY + bob}) scale(${zoom}) translate(${-fx} ${-fy})`}>
          <ellipse cx={cx0} cy={cy0 + 260} rx={520} ry={150} fill="url(#shadow)" />
          {sorted.map((b, i) => (
            <BoxView key={i} b={b} />
          ))}
          {o.glows.map((g, i) => {
            const [gx, gy] = proj(g.p[0], g.p[1], g.p[2]);
            return <circle key={i} cx={gx} cy={gy} r={g.r} fill={`url(#gl${i})`} opacity={clamp(g.k)} style={{mixBlendMode: 'screen'}} />;
          })}
        </g>

        <Fx o={o} t={t} amp={amp} />

        {o.dark > 0 && <rect width={WIDTH} height={HEIGHT} fill="#050a22" opacity={o.dark} />}
        <rect width={WIDTH} height={HEIGHT} fill={o.grade} />
        <rect width={WIDTH} height={HEIGHT} fill="url(#vig)" />
        <rect y={1100} width={WIDTH} height={820} fill="url(#capShade)" />
      </svg>
    </div>
  );
};
