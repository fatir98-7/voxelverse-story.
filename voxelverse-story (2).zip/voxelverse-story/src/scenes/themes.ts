import {ThemeId} from '../types';
import {clamp, easeInOut, lerp, mix, shade} from '../voxel/iso';
import {
  Ctx, SceneOut, Scn, character, clouds, debris, flowers, house, island, lampPost, rock, surf, tree,
} from './kit';

const GRASS = ['#7ccf4a', '#6cc043', '#8bd757'];
const pickGrass = (n: number) => GRASS[Math.floor(n * 2.99)];

const base = (S: Scn, o: Partial<SceneOut> & Pick<SceneOut, 'sky' | 'focus'>): SceneOut => ({
  boxes: S.boxes,
  glows: S.glows,
  fx: {},
  zoom: [1.0, 1.1],
  grade: 'rgba(255,170,90,0.10)',
  dark: 0,
  ...o,
});

// berjalan bolak-balik di jalur lurus; mengembalikan posisi + fase langkah
const walk = (c: Ctx, a: number, b: number) => {
  const p = easeInOut(clamp(c.t / Math.max(1, c.d - 0.6)));
  return {pos: lerp(a, b, p), phase: c.t * 7.5, moving: p > 0.01 && p < 0.99};
};

// ---------------- 1. FAJAR: padang rumput, matahari terbit ----------------
function dawn(c: Ctx): SceneOut {
  const S = new Scn(c);
  const I = island(S, {
    N: 13, R: 6.4, seed: c.seed,
    hf: (x, y, n) => (y === 6 ? 1 : 1 + (n > 0.62 && Math.abs(y - 6) > 1 ? 1 : 0)),
    top: (x, y, h, n) => (y === 6 ? '#d7b98a' : pickGrass(n)),
  });
  tree(S, 2, 2, surf(I, 2, 2), 'oak', 1.0);
  tree(S, 9, 3, surf(I, 9, 3), 'oak', 1.15);
  tree(S, 8, 9, surf(I, 8, 9), 'oak', 1.3);
  tree(S, 3, 9, surf(I, 3, 9), 'pine', 1.2);
  rock(S, 10, 8, surf(I, 10, 8), 0.9, 1.4);
  flowers(S, I, 46, ['#ff7aa8', '#ffe066', '#ffffff', '#ff9f4a'], 1.2, (x, y) => y === 6);
  // papan petunjuk
  S.box(5.5, 4.6, 1, 0.12, 0.12, 1.1, '#6b4426', {delay: 1.5});
  S.box(5.1, 4.55, 1.8, 0.9, 0.08, 0.4, '#c98e4b', {delay: 1.6});
  const w = walk(c, 1.2, 10.6);
  character(S, {x: w.pos, y: 6.35, z: surf(I, w.pos, 6.4), dir: 'x', phase: w.phase, moving: w.moving, delay: 0.9});
  clouds(S, 6);
  debris(S, 13, ['#7ccf4a', '#8a5a35', '#ffe066', '#ffffff', '#ff9f4a']);
  S.glow([6.5, 6.5, 6], 520, '#ffd48a', 0.35 + c.amp * 0.2, 0.2);
  return base(S, {
    focus: [6.5, 6.5, 1],
    sky: {
      top: '#ff9a6b', mid: '#ffc98f', bottom: '#ffeab9',
      sun: {x: 540, y: 520 + (1 - easeInOut(clamp(c.t / 5))) * 120, r: 150, color: '#fff1c2'},
      ridges: [{color: '#f3a98e', base: 690, amp: 120, seed: 3}, {color: '#e68f86', base: 740, amp: 90, seed: 9}],
    },
    fx: {birds: true, pollen: true, rays: true},
  });
}

// ---------------- 2. HUTAN + sungai + jembatan ----------------
function forest(c: Ctx): SceneOut {
  const S = new Scn(c);
  const river = (x: number, y: number) => Math.abs(x - y) < 1.6 && !(y > 5 && y < 8);
  const I = island(S, {
    N: 13, R: 6.5, seed: c.seed + 3,
    hf: (x, y, n) => (river(x, y) ? 0.6 : 1 + (n > 0.7 ? 1 : 0)),
    top: (x, y, h, n) => (river(x, y) ? '#3f9ad8' : mix('#4fae55', '#2f8a4f', n)),
    water: river,
  });
  // jembatan kayu
  for (let k = 0; k < 4; k++) S.box(5.2 + k * 0.6, 6, 1.0, 0.55, 1.1, 0.14, '#b98a52', {delay: 1.2 + k * 0.08});
  const rnd = S.rnd;
  for (let i = 0; i < 26; i++) {
    const x = Math.floor(rnd() * 12.5);
    const y = Math.floor(rnd() * 12.5);
    if (!I.on[x][y] || river(x, y) || (y >= 5 && y <= 8) || (x === 6 && y === 6)) continue;
    tree(S, x, y, surf(I, x, y), rnd() > 0.35 ? 'pine' : 'oak', 0.8 + rnd() * 1.4, 0.9 + rnd() * 0.5);
  }
  // jamur
  for (let i = 0; i < 6; i++) {
    const x = 2 + rnd() * 9;
    const y = 2 + rnd() * 9;
    const xi = Math.floor(x);
    const yi = Math.floor(y);
    if (!I.on[xi][yi] || river(xi, yi)) continue;
    const z = surf(I, x, y);
    S.box(x, y, z, 0.08, 0.08, 0.2, '#f4ecd8', {delay: 1.6 + i * 0.1});
    S.box(x - 0.1, y - 0.1, z + 0.2, 0.28, 0.28, 0.14, '#e0443a', {delay: 1.7 + i * 0.1});
  }
  const w = walk(c, 1.6, 10.4);
  character(S, {x: w.pos, y: 6.35, z: w.pos > 5 && w.pos < 7.6 ? 1.14 : 1, dir: 'x', phase: w.phase, moving: w.moving, delay: 0.9});
  clouds(S, 4);
  debris(S, 13, ['#4fae55', '#2f8a4f', '#8a5a35', '#bfe9ff']);
  return base(S, {
    focus: [6.5, 6.5, 1],
    sky: {
      top: '#7fcde0', mid: '#bfe9ea', bottom: '#eefbe6',
      sun: {x: 800, y: 400, r: 110, color: '#fffbd0'},
      ridges: [{color: '#8fcfb4', base: 700, amp: 110, seed: 21}, {color: '#6bb79a', base: 760, amp: 80, seed: 4}],
    },
    fx: {pollen: true, birds: true, rays: true},
    grade: 'rgba(120,220,200,0.10)',
    zoom: [1.02, 1.12],
  });
}

// ---------------- 3. DESA ----------------
function village(c: Ctx): SceneOut {
  const S = new Scn(c);
  const path = (x: number, y: number) => y === 6 || x === 6;
  const I = island(S, {
    N: 13, R: 6.5, seed: c.seed + 5,
    hf: () => 1,
    top: (x, y, h, n) => (path(x, y) ? mix('#cdbb9b', '#b9a684', n) : pickGrass(n)),
  });
  house(S, 2, 2, 1, 2.4, 2.2, 1.7, '#f2b27a', '#c1493a', 0.9, {chimney: true});
  house(S, 8, 2, 1, 2.2, 2.4, 2.0, '#9ec6c9', '#2d5f6e', 1.1);
  house(S, 8, 8.2, 1, 2.6, 2.4, 1.6, '#f0e1b8', '#8a4b2a', 1.3, {chimney: true});
  // sumur
  S.box(3.2, 8.4, 1, 0.9, 0.9, 0.5, '#9a9ea8', {delay: 1.4});
  S.box(3.35, 8.55, 1.5, 0.6, 0.6, 0.05, '#2f78b8', {delay: 1.45});
  S.box(3.2, 8.4, 1.5, 0.08, 0.08, 0.8, '#6b4426', {delay: 1.5});
  S.box(4.02, 8.4, 1.5, 0.08, 0.08, 0.8, '#6b4426', {delay: 1.5});
  S.box(3.1, 8.3, 2.3, 1.1, 1.1, 0.14, '#c1493a', {delay: 1.55});
  // lapak pasar (atap belang)
  for (let k = 0; k < 4; k++) S.box(0.6 + k * 0.4, 7.7, 1.9, 0.4, 1.3, 0.12, k % 2 ? '#ffffff' : '#e0443a', {delay: 1.6});
  S.box(0.7, 8.0, 1, 1.5, 0.7, 0.7, '#b98a52', {delay: 1.6});
  S.box(0.9, 8.1, 1.7, 0.3, 0.3, 0.22, '#e0443a', {delay: 1.7});
  S.box(1.4, 8.1, 1.7, 0.3, 0.3, 0.22, '#ffb000', {delay: 1.72});
  lampPost(S, 5, 5, 1, 1.5);
  lampPost(S, 7, 7, 1, 1.6);
  tree(S, 10.5, 5, 1, 'oak', 1.3);
  tree(S, 1.3, 5, 1, 'oak', 1.35);
  flowers(S, I, 30, ['#ff7aa8', '#ffe066', '#ffffff'], 1.5, path);
  const w = walk(c, 0.8, 11);
  character(S, {x: w.pos, y: 6.38, z: 1, dir: 'x', phase: w.phase, moving: w.moving, delay: 0.9, vest: '#2fa3b8'});
  clouds(S, 5);
  debris(S, 13, ['#f2b27a', '#9ec6c9', '#c1493a', '#ffffff']);
  return base(S, {
    focus: [6.5, 6.5, 1.5],
    sky: {
      top: '#6fb9f5', mid: '#a9dcff', bottom: '#e6f6ff',
      sun: {x: 220, y: 380, r: 100, color: '#fff6cc'},
      ridges: [{color: '#b8d6ee', base: 700, amp: 100, seed: 12}, {color: '#9cc3e0', base: 760, amp: 70, seed: 33}],
    },
    fx: {birds: true, pollen: true},
    grade: 'rgba(255,200,120,0.08)',
    zoom: [1.0, 1.1],
  });
}

// ---------------- 4. SAWAH BERTERAS (padi hijau -> menguning) ----------------
function farm(c: Ctx): SceneOut {
  const S = new Scn(c);
  const level = (y: number) => (y < 4 ? 3 : y < 8 ? 2 : 1);
  const I = island(S, {
    N: 13, R: 7, seed: c.seed + 9,
    hf: (x, y) => level(y),
    top: (x, y, h) => (y % 4 === 0 ? '#7a5a38' : '#5aa63e'),
    soil: '#7a5230',
  });
  const grow = clamp(c.t / (c.d * 0.9));
  const crop = mix('#79c24a', '#e8b93c', grow);
  const rnd = S.rnd;
  for (let y = 1; y < 12; y++) {
    if (y % 4 === 0) continue;
    for (let x = 1; x < 12; x++) {
      if (!I.on[x][y]) continue;
      if (x > 8 && y < 4) continue; // lahan rumah
      const z = I.h[x][y];
      const ht = 0.3 + grow * 0.45 + ((x * 7 + y * 3) % 3) * 0.04;
      const sway = Math.sin(c.t * 2 + x * 0.6) * 0.03;
      S.box(x + 0.12 + sway, y + 0.15, z, 0.3, 0.3, ht, crop, {delay: 1.0 + (x + y) * 0.05 + rnd() * 0.15});
      S.box(x + 0.55 + sway, y + 0.5, z, 0.3, 0.3, ht * 0.95, shade(crop, 1.08), {delay: 1.05 + (x + y) * 0.05 + rnd() * 0.15});
    }
  }
  // lumbung
  house(S, 9, 1, 3, 2.4, 2.0, 1.3, '#c9a066', '#8a4b2a', 1.4);
  // orang-orangan sawah
  S.box(4.4, 5.6, 2, 0.1, 0.1, 1.2, '#6b4426', {delay: 1.8});
  S.box(4.0, 5.55, 2.7, 0.9, 0.08, 0.1, '#6b4426', {delay: 1.85});
  S.box(4.3, 5.5, 3.1, 0.3, 0.3, 0.3, '#f2c29b', {delay: 1.9});
  S.box(4.15, 5.35, 3.35, 0.6, 0.6, 0.08, '#d9a441', {delay: 1.95});
  tree(S, 0.4, 9.5, 1, 'oak', 1.6, 0.9);
  tree(S, 11, 9.8, 1, 'oak', 1.7, 0.9);
  const w = walk(c, 1.5, 10.5);
  character(S, {x: w.pos, y: 7.4, z: 2, dir: 'x', phase: w.phase, moving: w.moving, delay: 1.0, vest: '#e0443a'});
  clouds(S, 5, '#fffaf0');
  debris(S, 13, ['#79c24a', '#e8b93c', '#7a5230', '#ffffff']);
  S.glow([6.5, 6.5, 6], 500, '#ffe3a0', 0.3 + c.amp * 0.15, 0.3);
  return base(S, {
    focus: [6.5, 6.5, 2],
    sky: {
      top: '#ffbe7a', mid: '#ffdca0', bottom: '#fff3d0',
      sun: {x: 780, y: 470, r: 130, color: '#fff2bd'},
      ridges: [{color: '#e8b98a', base: 700, amp: 110, seed: 40}, {color: '#d9a07a', base: 750, amp: 80, seed: 41}],
    },
    fx: {birds: true, pollen: true, rays: true},
    grade: 'rgba(255,190,100,0.12)',
    zoom: [1.0, 1.12],
  });
}

// ---------------- 5. KOTA HUJAN ----------------
function rain(c: Ctx): SceneOut {
  const S = new Scn(c);
  const road = (x: number, y: number) => y >= 5 && y <= 7;
  const I = island(S, {
    N: 13, R: 7, seed: c.seed + 13, square: false,
    hf: () => 1,
    top: (x, y, h, n) => (road(x, y) ? mix('#454c5a', '#3c4350', n) : mix('#8a91a0', '#7a8190', n)),
    soil: '#4a4f5c', stone: '#555b6a',
  });
  // marka jalan
  for (let x = 1; x < 12; x += 2) if (I.on[x][6]) S.box(x + 0.15, 6.4, 1, 0.7, 0.14, 0.02, '#e8e2c2', {delay: 1.0 + x * 0.04});
  // genangan
  for (const [x, y] of [[3, 5.3], [8, 7.1], [10, 5.6]] as [number, number][]) {
    const sh = 0.5 + 0.5 * Math.sin(c.t * 3 + x);
    S.box(x, y, 1, 1.2, 0.8, 0.02, mix('#5b7fa8', '#8fb3d8', sh), {delay: 1.3});
  }
  const cols = ['#c97b63', '#7d8fa3', '#b88f6d', '#5d6d7e', '#a56f7a'];
  const blds: [number, number, number, number, number][] = [
    [1, 1, 2.6, 2.6, 6], [4.2, 1, 2.2, 2.4, 4.2], [8, 1.2, 2.8, 2.4, 5.2],
    [1, 8.8, 2.4, 2.8, 4.6], [8.4, 9, 2.6, 2.6, 6.2],
  ];
  blds.forEach(([x, y, w, d, h], i) => {
    const dl = 0.8 + i * 0.18;
    const col = cols[i % cols.length];
    S.box(x, y, 1, w, d, h, col, {delay: dl, lines: true});
    S.box(x - 0.1, y - 0.1, 1 + h, w + 0.2, d + 0.2, 0.18, shade(col, 0.7), {delay: dl + 0.3});
    for (let k = 0; k < Math.floor(h - 1); k++) {
      for (let j = 0; j < Math.floor(d / 0.8); j++) {
        const lit = ((k * 5 + j * 3 + i * 7) % 4) !== 0;
        S.box(x + w, y + 0.25 + j * 0.8, 1.6 + k, 0.05, 0.4, 0.5, lit ? '#ffd98a' : '#33425a', {delay: dl + 0.4 + k * 0.05});
      }
      for (let j = 0; j < Math.floor(w / 0.8); j++) {
        const lit = ((k * 3 + j * 5 + i * 2) % 4) !== 1;
        S.box(x + 0.25 + j * 0.8, y + d, 1.6 + k, 0.4, 0.05, 0.5, lit ? '#ffd98a' : '#33425a', {delay: dl + 0.4 + k * 0.05});
      }
    }
    S.glow([x + w + 0.1, y + d / 2, 1 + h * 0.6], 150, '#ffb860', 0.28, dl + 0.5);
  });
  lampPost(S, 3, 4, 1, 1.4, '#ffd27a', 1.0);
  lampPost(S, 7.5, 8, 1, 1.5, '#ffd27a', 1.0);
  lampPost(S, 11, 4, 1, 1.6, '#ffd27a', 1.0);
  const w = walk(c, 1, 11);
  character(S, {x: w.pos, y: 6.3, z: 1, dir: 'x', phase: w.phase, moving: w.moving, delay: 0.9, umbrella: '#e0443a', vest: '#4aa3ff'});
  clouds(S, 7, '#8c97ab', 0.95);
  debris(S, 13, ['#5d6d7e', '#c97b63', '#ffd98a', '#8c97ab']);
  return base(S, {
    focus: [6.5, 6.5, 2.2],
    sky: {top: '#2f3a55', mid: '#55647f', bottom: '#8d9bb3', ridges: [{color: '#4a566e', base: 720, amp: 90, seed: 55}]},
    fx: {rain: true},
    grade: 'rgba(60,90,140,0.18)',
    dark: 0.18,
    zoom: [1.0, 1.08],
  });
}

// ---------------- 6. GUNUNG ----------------
function mountain(c: Ctx): SceneOut {
  const S = new Scn(c);
  const N = 13;
  const I = island(S, {
    N, R: 6.6, seed: c.seed + 17,
    hf: (x, y, n) => {
      const d = Math.hypot(x + 0.5 - 6.5, y + 0.5 - 6.5);
      return Math.max(1, Math.round(7 - d * 1.05 + n * 1.3));
    },
    top: (x, y, h, n) => (h >= 6 ? '#f4f8ff' : h >= 4 ? mix('#9aa3b2', '#7c8696', n) : h >= 2 ? '#5aa63e' : '#7ccf4a'),
    stone: '#6c7688',
  });
  const rnd = S.rnd;
  for (let i = 0; i < 30; i++) {
    const x = Math.floor(rnd() * 12.5);
    const y = Math.floor(rnd() * 12.5);
    if (!I.on[x][y]) continue;
    const z = surf(I, x, y);
    if (z > 3) continue;
    tree(S, x, y, z, 'pine', 0.9 + rnd() * 1.2, 0.8 + rnd() * 0.4);
  }
  // bendera di puncak
  const top = Math.max(...I.h.flat());
  let tx = 6;
  let ty = 6;
  I.h.forEach((row, x) => row.forEach((v, y) => { if (v === top && Math.hypot(x - 6, y - 6) < Math.hypot(tx - 6, ty - 6)) { tx = x; ty = y; } }));
  S.box(tx + 0.45, ty + 0.45, top, 0.1, 0.1, 1.8, '#5b3a22', {delay: 2.0});
  for (let k = 0; k < 4; k++) S.box(tx + 0.55 + k * 0.2, ty + 0.4 + Math.sin(c.t * 5 + k) * 0.06, top + 1.3, 0.2, 0.06, 0.45, '#e0443a', {delay: 2.1});
  clouds(S, 6, '#ffffff', 0.9);
  debris(S, N, ['#f4f8ff', '#9aa3b2', '#5aa63e', '#bfe0ff']);
  S.glow([tx, ty, top + 2], 380, '#fff2c0', 0.3 + c.amp * 0.2, 0.5);
  return base(S, {
    focus: [6.5, 6.5, 3.6],
    sky: {
      top: '#5aa2ea', mid: '#9ccdf5', bottom: '#e0f1ff',
      sun: {x: 860, y: 330, r: 100, color: '#ffffff'},
      ridges: [{color: '#aac4e0', base: 690, amp: 130, seed: 61}],
    },
    fx: {birds: true, rays: true},
    grade: 'rgba(180,220,255,0.10)',
    zoom: [0.95, 1.08],
  });
}

// ---------------- 7. PANTAI SENJA ----------------
function beach(c: Ctx): SceneOut {
  const S = new Scn(c);
  const sea = (x: number, y: number) => Math.hypot(x + 0.5 - 6.5, y + 0.5 - 6.5) > 4.6;
  const I = island(S, {
    N: 13, R: 6.9, seed: c.seed + 21, square: true,
    hf: (x, y) => (sea(x, y) ? 0.6 : 1),
    top: (x, y, h, n) => (sea(x, y) ? '#3fa5e0' : mix('#f2dca4', '#e8c98a', n)),
    water: sea,
    soil: '#d4b074', stone: '#9a7f55',
  });
  // pohon kelapa
  const palm = (x: number, y: number, dl: number) => {
    const z = 1;
    for (let k = 0; k < 5; k++) S.box(x + k * 0.07, y + k * 0.05, z + k * 0.45, 0.22, 0.22, 0.46, '#8a5a35', {delay: dl + k * 0.05});
    const [tx, ty, tz] = [x + 0.35, y + 0.25, z + 2.25];
    const sw = Math.sin(c.t * 1.8 + x) * 0.12;
    S.box(tx - 0.9 + sw, ty + 0.05, tz, 2.1, 0.3, 0.14, '#3aa04a', {delay: dl + 0.3});
    S.box(tx + 0.05, ty - 0.9 + sw, tz, 0.3, 2.1, 0.14, '#2f8a3f', {delay: dl + 0.32});
    S.box(tx - 0.4 + sw, ty - 0.4, tz + 0.14, 1.1, 1.1, 0.14, '#4cb85a', {delay: dl + 0.35});
  };
  palm(3, 4, 1.0);
  palm(8, 3.4, 1.15);
  palm(5, 9, 1.3);
  // payung & handuk
  S.box(7.5, 7.5, 1, 0.08, 0.08, 1.6, '#6b4426', {delay: 1.5});
  S.box(6.9, 6.9, 2.5, 1.3, 1.3, 0.12, '#e0443a', {delay: 1.55});
  S.box(7.2, 7.2, 2.62, 0.7, 0.7, 0.1, '#ffffff', {delay: 1.6});
  S.box(6.2, 8, 1, 0.9, 0.5, 0.04, '#4aa3ff', {delay: 1.6});
  // perahu mengayun di laut
  const bob = Math.sin(c.t * 1.7) * 0.06;
  const bx = 1.2 + Math.sin(c.t * 0.5) * 0.3;
  S.box(bx, 10.6, 0.65 + bob, 1.6, 0.7, 0.3, '#b9743f', {delay: 1.4, k: 30});
  S.box(bx + 0.7, 10.85, 0.95 + bob, 0.08, 0.08, 1.3, '#6b4426', {delay: 1.5, k: 30.1});
  S.box(bx + 0.78, 10.8, 1.2 + bob, 0.04, 0.7, 0.9, '#ffffff', {delay: 1.55, k: 30.2});
  const w = walk(c, 3.2, 9.8);
  character(S, {x: w.pos, y: 6.6, z: 1, dir: 'x', phase: w.phase, moving: w.moving, delay: 0.9, vest: '#ffd23f'});
  clouds(S, 5, '#ffe3cf', 0.9);
  debris(S, 13, ['#f2dca4', '#3fa5e0', '#ffffff', '#ff8a5a']);
  S.glow([6.5, 6.5, 5], 560, '#ff9a5a', 0.3 + c.amp * 0.15, 0.2);
  return base(S, {
    focus: [6.5, 6.5, 1.2],
    sky: {
      top: '#ff7a59', mid: '#ffae6a', bottom: '#ffe0a0',
      sun: {x: 540, y: 600, r: 190, color: '#ffe9a8'},
      ridges: [{color: '#e3748c', base: 700, amp: 70, seed: 71}],
    },
    fx: {birds: true},
    grade: 'rgba(255,120,80,0.14)',
    zoom: [1.0, 1.12],
  });
}

// ---------------- 8. MALAM: api unggun ----------------
function night(c: Ctx): SceneOut {
  const S = new Scn(c);
  const I = island(S, {
    N: 13, R: 6.4, seed: c.seed + 25,
    hf: (x, y, n) => 1 + (n > 0.7 ? 1 : 0),
    top: (x, y, h, n) => mix('#3a7a66', '#2f6354', n),
    soil: '#4a3a30', stone: '#3c4458',
  });
  const rnd = S.rnd;
  for (let i = 0; i < 20; i++) {
    const x = Math.floor(rnd() * 12.5);
    const y = Math.floor(rnd() * 12.5);
    if (!I.on[x][y] || Math.hypot(x - 6.5, y - 6.5) < 3) continue;
    tree(S, x, y, surf(I, x, y), 'dark', 0.8 + rnd() * 1.2, 0.9 + rnd() * 0.4);
  }
  const fz = surf(I, 6, 6);
  const fl = 0.8 + c.amp * 0.5 + Math.sin(c.t * 13) * 0.08;
  S.box(5.7, 5.7, fz, 0.9, 0.2, 0.2, '#5b3a22', {delay: 1.0});
  S.box(6.0, 5.5, fz, 0.2, 0.9, 0.2, '#6b4426', {delay: 1.05});
  S.box(5.85, 5.85, fz + 0.1, 0.45, 0.45, 0.5 * fl, '#ff9a2f', {delay: 1.1, k: 12.5});
  S.box(5.95, 5.95, fz + 0.4, 0.25, 0.25, 0.5 * fl, '#ffe066', {delay: 1.15, k: 12.6});
  S.glow([6.1, 6.1, fz + 0.6], 420, '#ff9a3c', 0.85 * fl, 0.9);
  // tenda
  const tz = surf(I, 8, 4);
  S.box(8, 3.6, tz, 2.2, 1.8, 0.5, '#e0725a', {delay: 1.3});
  S.box(8.25, 3.85, tz + 0.5, 1.7, 1.3, 0.5, shade('#e0725a', 1.1), {delay: 1.35});
  S.box(8.55, 4.1, tz + 1.0, 1.1, 0.8, 0.4, shade('#e0725a', 1.2), {delay: 1.4});
  lampPost(S, 3.5, 8.5, surf(I, 3, 8), 1.4, '#9fd8ff', 0.7);
  character(S, {x: 4.6, y: 6.1, z: fz, dir: 'x', phase: 0, moving: false, delay: 0.9, vest: '#ff7a2f'});
  // kunang-kunang & asap api
  for (let k = 0; k < 5; k++) {
    const ph = (c.t * 0.35 + k / 5) % 1;
    const s = 0.12 + ph * 0.1;
    S.boxes.push({x: 6.1 + Math.sin(ph * 7 + k) * 0.3, y: 6.1 + Math.cos(ph * 6 + k) * 0.3, z: fz + 0.7 + ph * 3, w: s, d: s, h: s, c: '#ffb04a', op: (1 - ph) * 0.9, k: 13 + k * 0.01});
  }
  debris(S, 13, ['#2d5a52', '#ffe066', '#7ab8ff', '#ffffff']);
  return base(S, {
    focus: [6.5, 6.5, 1.5],
    sky: {top: '#080c28', mid: '#1c2a62', bottom: '#4a5496', moon: true, stars: true, ridges: [{color: '#1c2550', base: 700, amp: 100, seed: 81}, {color: '#141b3f', base: 760, amp: 80, seed: 82}]},
    fx: {fireflies: true},
    grade: 'rgba(40,60,160,0.10)',
    dark: 0.14,
    zoom: [1.02, 1.14],
  });
}

export const THEMES: Record<ThemeId, (c: Ctx) => SceneOut> = {
  dawn, forest, village, farm, rain, mountain, beach, night,
};
