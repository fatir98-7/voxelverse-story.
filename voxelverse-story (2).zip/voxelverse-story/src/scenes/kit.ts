import {BoxSpec, clamp, easeOutBack, lerp, mix, mulberry32, shade, vnoise} from '../voxel/iso';

export type Ctx = {
  t: number; // detik sejak adegan mulai
  d: number; // durasi adegan (detik)
  amp: number; // amplitudo suara 0..1 (sinkron voice over)
  seed: number;
};

export type Glow = {p: [number, number, number]; r: number; color: string; k: number};

export type Sky = {
  top: string;
  mid: string;
  bottom: string;
  sun?: {x: number; y: number; r: number; color: string};
  moon?: boolean;
  stars?: boolean;
  ridges?: {color: string; base: number; amp: number; seed: number}[];
};

export type Fx = {rain?: boolean; fireflies?: boolean; birds?: boolean; pollen?: boolean; rays?: boolean};

export type SceneOut = {
  boxes: BoxSpec[];
  glows: Glow[];
  sky: Sky;
  fx: Fx;
  focus: [number, number, number];
  zoom: [number, number]; // zoom awal -> akhir
  grade: string; // warna color-grade overlay
  dark: number; // 0..1 kegelapan keseluruhan (malam)
};

/** Pembangun adegan: menumpuk BoxSpec dengan animasi "tumbuh" (build-up voxel). */
export class Scn {
  boxes: BoxSpec[] = [];
  glows: Glow[] = [];
  rnd: () => number;
  constructor(public c: Ctx) {
    this.rnd = mulberry32(c.seed);
  }
  /** faktor tumbuh 0..~1.07 (overshoot) setelah delay detik */
  g(delay: number, dur = 0.7) {
    return easeOutBack(clamp((this.c.t - delay) / dur, 0, 1));
  }
  /** kotak yang tumbuh dari dasarnya */
  box(
    x: number, y: number, z: number, w: number, d: number, h: number, c: string,
    o: {delay?: number; lines?: boolean; layer?: number; op?: number; k?: number; fixed?: boolean} = {},
  ) {
    const g = o.fixed ? 1 : this.g(o.delay ?? 0);
    if (g <= 0.001) return;
    const op = (o.op ?? 1) * clamp(g * 2.5);
    this.boxes.push({x, y, z, w, d, h: h * g, c, layer: o.layer, lines: o.lines, op, k: o.k});
  }
  glow(p: [number, number, number], r: number, color: string, k: number, delay = 0) {
    const g = clamp(this.g(delay));
    if (g > 0.01) this.glows.push({p, r, color, k: k * g});
  }
}

// ---------- pulau melayang ----------
export type IslandCfg = {
  N: number;
  R: number;
  square?: boolean;
  seed: number;
  hf: (x: number, y: number, n: number) => number;
  top: (x: number, y: number, h: number, n: number) => string;
  water?: (x: number, y: number) => boolean;
  soil?: string;
  stone?: string;
};
export type IslandInfo = {h: number[][]; on: boolean[][]; N: number};

export function island(S: Scn, cfg: IslandCfg): IslandInfo {
  const {N, R, seed} = cfg;
  const h: number[][] = [];
  const on: boolean[][] = [];
  const soil = cfg.soil ?? '#8a5a35';
  const stone = cfg.stone ?? '#6f7b8f';
  const t = S.c.t;
  for (let x = 0; x < N; x++) {
    h[x] = [];
    on[x] = [];
    for (let y = 0; y < N; y++) {
      const dx = x + 0.5 - N / 2;
      const dy = y + 0.5 - N / 2;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const en = vnoise(x * 0.8, y * 0.8, seed + 7) * 1.4;
      const inside = cfg.square ? true : dist < R - en;
      on[x][y] = inside;
      const n = vnoise(x * 0.45, y * 0.45, seed);
      h[x][y] = inside ? cfg.hf(x, y, n) : 0;
      if (!inside) continue;
      const wet = cfg.water?.(x, y) ?? false;
      const g = S.g(dist * 0.045 + 0.05, 0.8);
      const dz = -(1 - g) * 5;
      const op = clamp(g * 2.2);
      const depth = cfg.square ? 3.2 : 2 + Math.max(0, R - dist) * 0.85;
      if (wet) {
        const wave = Math.sin(t * 2 + x * 0.9 + y * 0.6) * 0.5 + 0.5;
        const hh = h[x][y];
        const col = mix('#3f9ad8', '#7cc7f0', wave * 0.55 + n * 0.25);
        S.boxes.push({x, y, z: -depth + dz, w: 1, d: 1, h: depth + hh - 0.3, c: '#2f6fa8', op});
        S.boxes.push({x, y, z: hh - 0.3 + dz, w: 1, d: 1, h: 0.3, c: col, op});
        continue;
      }
      const hh = h[x][y];
      const top = shade(cfg.top(x, y, hh, n), 0.93 + n * 0.14);
      const soilTop = hh - 0.3;
      const soilBot = Math.max(soilTop - 1.0, -depth);
      S.boxes.push({x, y, z: soilBot + dz, w: 1, d: 1, h: soilTop - soilBot, c: shade(soil, 0.9 + n * 0.2), op});
      if (soilBot > -depth + 0.01) {
        S.boxes.push({x, y, z: -depth + dz, w: 1, d: 1, h: soilBot + depth, c: shade(stone, 0.85 + n * 0.25), op});
      }
      S.boxes.push({x, y, z: soilTop + dz, w: 1, d: 1, h: 0.3, c: top, op});
    }
  }
  return {h, on, N};
}

/** tinggi permukaan di (x,y) dunia */
export const surf = (I: IslandInfo, x: number, y: number) => {
  const xi = Math.max(0, Math.min(I.N - 1, Math.floor(x)));
  const yi = Math.max(0, Math.min(I.N - 1, Math.floor(y)));
  return I.h[xi][yi];
};

// ---------- dekorasi ----------
export function tree(S: Scn, x: number, y: number, z: number, kind: 'pine' | 'oak' | 'dark', delay: number, scale = 1) {
  const t = S.c.t;
  const sway = Math.sin(t * 1.5 + x * 0.8 + y * 0.5) * 0.05;
  const trunk = '#6b4426';
  if (kind === 'oak') {
    const cA = '#4fae43';
    S.box(x + 0.4, y + 0.4, z, 0.22, 0.22, 1.0 * scale, trunk, {delay});
    S.box(x - 0.1 + sway, y - 0.1, z + 0.9 * scale, 1.2, 1.2, 1.0 * scale, cA, {delay: delay + 0.1});
    S.box(x + 0.1 + sway * 1.6, y + 0.1, z + 1.7 * scale, 0.8, 0.8, 0.6 * scale, shade(cA, 1.1), {delay: delay + 0.18});
    return;
  }
  const cA = kind === 'dark' ? '#1f5a46' : '#2f8a4f';
  S.box(x + 0.4, y + 0.4, z, 0.2, 0.2, 0.6 * scale, trunk, {delay});
  const layers: [number, number][] = [[0.95, 0.5], [0.7, 0.9], [0.45, 1.3], [0.22, 1.7]];
  layers.forEach(([sz, zz], i) => {
    const s = sz * scale;
    S.box(x + 0.5 - s / 2 + sway * i * 0.8, y + 0.5 - s / 2, z + zz * scale, s, s, 0.5 * scale, shade(cA, 1 + i * 0.07), {
      delay: delay + 0.05 * i,
    });
  });
}

export function house(
  S: Scn, x: number, y: number, z: number, w: number, d: number, h: number,
  wall: string, roof: string, delay: number, opt: {chimney?: boolean; lit?: boolean} = {},
) {
  const t = S.c.t;
  S.box(x, y, z, w, d, h, wall, {delay, lines: true});
  // atap bertingkat
  let rx = x - 0.15;
  let ry = y - 0.15;
  let rw = w + 0.3;
  let rd = d + 0.3;
  let rz = z + h;
  let i = 0;
  while (rw > 0.5 && rd > 0.5 && i < 4) {
    S.box(rx, ry, rz, rw, rd, 0.32, shade(roof, 1 + i * 0.06), {delay: delay + 0.12 + i * 0.05});
    rx += 0.28;
    ry += 0.28;
    rw -= 0.56;
    rd -= 0.56;
    rz += 0.32;
    i++;
  }
  // pintu (sisi +y) dan jendela (sisi +x)
  S.box(x + w * 0.35, y + d, z, 0.5, 0.05, 0.85, '#5a3a22', {delay: delay + 0.3});
  const flick = 0.75 + S.c.amp * 0.25 + Math.sin(t * 9 + x) * 0.04;
  S.box(x + w, y + d * 0.28, z + h * 0.45, 0.05, 0.5, 0.45, opt.lit === false ? '#9ab' : '#ffe08a', {delay: delay + 0.35});
  S.box(x + w * 0.62, y + d, z + h * 0.5, 0.4, 0.05, 0.4, opt.lit === false ? '#9ab' : '#ffe08a', {delay: delay + 0.35});
  if (opt.lit !== false) {
    const [gx, gy, gz] = [x + w + 0.1, y + d * 0.5, z + h * 0.65] as [number, number, number];
    S.glow([gx, gy, gz], 120, '#ffc860', 0.5 * flick, delay + 0.4);
  }
  if (opt.chimney) {
    S.box(x + 0.25, y + 0.25, z + h, 0.3, 0.3, 1.1, '#7a4a3a', {delay: delay + 0.4});
    const top = z + h + 1.1;
    for (let k = 0; k < 5; k++) {
      const ph = (t * 0.4 + k / 5) % 1;
      const s = 0.2 + ph * 0.3 + S.c.amp * 0.05;
      S.boxes.push({
        x: x + 0.3 + Math.sin(ph * 5 + k) * 0.15 + ph * 0.5,
        y: y + 0.3 + Math.cos(ph * 4 + k) * 0.1,
        z: top + ph * 2.3,
        w: s, d: s, h: s, c: '#f4f4f6', op: (1 - ph) * 0.55 * clamp(S.g(delay + 0.8)), k: x + y + 40,
      });
    }
  }
}

export function lampPost(S: Scn, x: number, y: number, z: number, delay: number, color = '#ffd27a', k = 0.8) {
  S.box(x + 0.4, y + 0.4, z, 0.14, 0.14, 1.5, '#2c3440', {delay});
  S.box(x + 0.32, y + 0.32, z + 1.5, 0.3, 0.3, 0.3, color, {delay: delay + 0.1});
  const fl = 0.8 + S.c.amp * 0.35 + Math.sin(S.c.t * 11 + x * 3) * 0.05;
  S.glow([x + 0.47, y + 0.47, z + 1.7], 170, color, k * fl, delay + 0.2);
}

export function rock(S: Scn, x: number, y: number, z: number, s: number, delay: number, c = '#8f9aa8') {
  S.box(x, y, z, s, s * 0.9, s * 0.6, c, {delay});
  S.box(x + s * 0.15, y + s * 0.15, z + s * 0.6, s * 0.6, s * 0.55, s * 0.35, shade(c, 1.1), {delay: delay + 0.05});
}

export function flowers(S: Scn, I: IslandInfo, count: number, colors: string[], delay: number, skip?: (x: number, y: number) => boolean) {
  const r = S.rnd;
  for (let i = 0; i < count; i++) {
    const x = r() * (I.N - 1);
    const y = r() * (I.N - 1);
    const xi = Math.floor(x);
    const yi = Math.floor(y);
    if (!I.on[xi]?.[yi] || (skip && skip(xi, yi))) continue;
    const z = I.h[xi][yi];
    const c = colors[Math.floor(r() * colors.length)];
    const dl = delay + r() * 1.2;
    S.box(x, y, z, 0.07, 0.07, 0.22, '#3f8f3a', {delay: dl});
    S.box(x - 0.04, y - 0.04, z + 0.2, 0.16, 0.16, 0.12, c, {delay: dl + 0.05});
  }
}

export function clouds(S: Scn, count: number, color = '#ffffff', alpha = 0.92) {
  const r = S.rnd;
  const t = S.c.t;
  for (let i = 0; i < count; i++) {
    const base = r() * 18 - 4;
    const yy = -3 + r() * 5;
    const zz = 7 + r() * 4;
    const x = ((base + t * (0.25 + r() * 0.2) + 6) % 24) - 6;
    const s = 1 + r() * 1.2;
    S.boxes.push({x, y: yy, z: zz, w: 2.6 * s, d: 1.4 * s, h: 0.7, c: color, op: alpha, k: x + yy + 2});
    S.boxes.push({x: x + 0.5 * s, y: yy + 0.2, z: zz + 0.7, w: 1.4 * s, d: 0.9 * s, h: 0.5, c: color, op: alpha, k: x + yy + 2.1});
  }
}

/** kubus-kubus melayang di sekitar pulau (ciri VOXELVERSE) */
export function debris(S: Scn, N: number, palette: string[], count = 14) {
  const r = S.rnd;
  const t = S.c.t;
  for (let i = 0; i < count; i++) {
    const a = r() * Math.PI * 2;
    const rad = N * 0.62 + r() * 2.6;
    const x = N / 2 + Math.cos(a) * rad;
    const y = N / 2 + Math.sin(a) * rad;
    const z0 = -2 + r() * 7;
    const sz = 0.22 + r() * 0.4;
    const ph = r() * 6.28;
    const z = z0 + Math.sin(t * (0.8 + r() * 0.6) + ph) * (0.35 + S.c.amp * 0.5);
    const g = clamp(S.g(0.4 + r() * 1.2, 0.9));
    S.boxes.push({x, y, z, w: sz, d: sz, h: sz, c: palette[i % palette.length], op: g * 0.95, k: x + y + sz * 2 + z * 0.01});
  }
}

// ---------- karakter voxel orisinal: penjelajah bertopi caping ----------
export type CharOpt = {
  x: number; y: number; z: number;
  dir: 'x' | 'y';
  phase: number; // fase langkah
  moving?: boolean;
  delay?: number;
  vest?: string;
  umbrella?: string;
  scale?: number;
};

export function character(S: Scn, o: CharOpt) {
  const s = o.scale ?? 1;
  const mv = o.moving ?? true;
  const sw = mv ? Math.sin(o.phase) : 0;
  const bob = (mv ? Math.abs(Math.sin(o.phase)) * 0.05 : Math.sin(S.c.t * 2) * 0.01) * s + S.c.amp * 0.02;
  const dl = o.delay ?? 0;
  const vest = o.vest ?? '#ff7a2f';
  // sumbu lokal: f = maju, q = samping
  const put = (f: number, q: number, z: number, wf: number, wq: number, h: number, c: string, extra = 0) => {
    const F = f * s;
    const Q = q * s;
    const wx = o.dir === 'x' ? wf * s : wq * s;
    const wy = o.dir === 'x' ? wq * s : wf * s;
    const px = o.dir === 'x' ? o.x + F : o.x + Q;
    const py = o.dir === 'x' ? o.y + Q : o.y + F;
    S.box(px, py, o.z + (z + bob) * s, wx, wy, h * s, c, {delay: dl + extra, k: o.x + o.y + 0.9 + (o.dir === 'x' ? F : Q) * 0.01 + z * 0.001, fixed: false});
  };
  // kaki
  put(-0.07 + sw * 0.16, -0.17, 0, 0.14, 0.14, 0.4, '#2f4a7a');
  put(-0.07 - sw * 0.16, 0.03, 0, 0.14, 0.14, 0.4, '#27406b');
  // badan + rompi
  put(-0.13, -0.2, 0.4, 0.26, 0.4, 0.5, '#f1f1ee', 0.05);
  put(-0.14, -0.21, 0.42, 0.28, 0.14, 0.44, vest, 0.08);
  put(-0.14, 0.07, 0.42, 0.28, 0.14, 0.44, vest, 0.08);
  // lengan
  put(-0.06 - sw * 0.16, -0.33, 0.45, 0.12, 0.12, 0.4, '#f1f1ee', 0.1);
  put(-0.06 + sw * 0.16, 0.21, 0.45, 0.12, 0.12, 0.4, '#f1f1ee', 0.1);
  // kepala
  put(-0.17, -0.17, 0.9, 0.34, 0.34, 0.34, '#f2c29b', 0.12);
  put(0.15, -0.1, 1.05, 0.03, 0.07, 0.07, '#222', 0.2);
  put(0.15, 0.05, 1.05, 0.03, 0.07, 0.07, '#222', 0.2);
  put(-0.19, -0.19, 1.14, 0.38, 0.38, 0.1, '#3a2418', 0.14); // rambut
  // syal
  put(-0.15, -0.22, 0.84, 0.3, 0.44, 0.1, '#ffffff', 0.12);
  // topi caping
  put(-0.34, -0.34, 1.24, 0.68, 0.68, 0.06, '#d9a441', 0.16);
  put(-0.15, -0.15, 1.3, 0.3, 0.3, 0.2, shade('#d9a441', 1.1), 0.18);
  if (o.umbrella) {
    put(-0.04, -0.03, 1.45, 0.06, 0.06, 0.2, '#333', 0.2);
    put(-0.5, -0.5, 1.62, 1.0, 1.0, 0.1, o.umbrella, 0.2);
    put(-0.3, -0.3, 1.72, 0.6, 0.6, 0.08, shade(o.umbrella, 1.12), 0.22);
  }
}
export {lerp};
