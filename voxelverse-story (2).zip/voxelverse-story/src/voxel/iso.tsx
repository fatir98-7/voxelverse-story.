import React from 'react';

/** Proyeksi isometrik 2:1. Sumbu: x ke kanan-bawah, y ke kiri-bawah, z ke atas. */
export const TW = 96; // lebar 1 ubin (px)
export const VH = 52; // tinggi 1 voxel (px)

export const proj = (x: number, y: number, z: number): [number, number] => [
  ((x - y) * TW) / 2,
  ((x + y) * TW) / 4 - z * VH,
];

// ---------- warna ----------
const clamp255 = (n: number) => Math.max(0, Math.min(255, Math.round(n)));
export const rgb = (c: string): [number, number, number] => {
  const h = c.replace('#', '');
  const f = h.length === 3 ? h.split('').map((x) => x + x).join('') : h;
  return [parseInt(f.slice(0, 2), 16), parseInt(f.slice(2, 4), 16), parseInt(f.slice(4, 6), 16)];
};
export const toHex = (r: number, g: number, b: number) =>
  '#' + [r, g, b].map((v) => clamp255(v).toString(16).padStart(2, '0')).join('');

/** f<1 menggelapkan, f>1 mencerahkan (menuju putih) */
export const shade = (c: string, f: number): string => {
  const [r, g, b] = rgb(c);
  if (f <= 1) return toHex(r * f, g * f, b * f);
  const k = f - 1;
  return toHex(r + (255 - r) * k, g + (255 - g) * k, b + (255 - b) * k);
};
export const mix = (a: string, b: string, t: number): string => {
  const A = rgb(a);
  const B = rgb(b);
  return toHex(A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, A[2] + (B[2] - A[2]) * t);
};

// ---------- kotak (primitif utama) ----------
export type BoxSpec = {
  x: number;
  y: number;
  z: number;
  w: number; // ukuran sepanjang x
  d: number; // ukuran sepanjang y
  h: number; // tinggi
  c: string;
  layer?: number; // 0 = dasar (digambar duluan)
  op?: number;
  lines?: boolean; // garis voxel di sisi
  k?: number; // override urutan kedalaman
};

export const depthKey = (b: BoxSpec) => b.k ?? b.x + b.w + (b.y + b.d) + b.z * 0.001;

export const sortBoxes = (boxes: BoxSpec[]): BoxSpec[] =>
  [...boxes].sort((a, b) => (a.layer ?? 1) - (b.layer ?? 1) || depthKey(a) - depthKey(b));

const f1 = (n: number) => n.toFixed(1);
const P = (pts: [number, number][]) => pts.map((p) => `${f1(p[0])},${f1(p[1])}`).join(' ');

export const BoxView: React.FC<{b: BoxSpec}> = ({b}) => {
  if (b.h <= 0.001 || (b.op !== undefined && b.op <= 0.01)) return null;
  const {x, y, z, w, d, h, c} = b;
  const z1 = z + h;
  const top = P([proj(x, y, z1), proj(x + w, y, z1), proj(x + w, y + d, z1), proj(x, y + d, z1)]);
  const left = P([proj(x, y + d, z), proj(x + w, y + d, z), proj(x + w, y + d, z1), proj(x, y + d, z1)]);
  const right = P([proj(x + w, y, z), proj(x + w, y + d, z), proj(x + w, y + d, z1), proj(x + w, y, z1)]);
  const cT = shade(c, 1.16);
  const cL = shade(c, 0.9);
  const cR = shade(c, 0.68);
  const lines: React.ReactNode[] = [];
  if (b.lines) {
    const n = Math.floor(h - 0.001);
    for (let i = 1; i <= n; i++) {
      const zz = z + i;
      const [a1, a2] = [proj(x, y + d, zz), proj(x + w, y + d, zz)];
      const [b1, b2] = [proj(x + w, y, zz), proj(x + w, y + d, zz)];
      lines.push(
        <line key={`l${i}`} x1={a1[0]} y1={a1[1]} x2={a2[0]} y2={a2[1]} stroke="rgba(0,0,0,0.16)" strokeWidth={1.4} />,
        <line key={`r${i}`} x1={b1[0]} y1={b1[1]} x2={b2[0]} y2={b2[1]} stroke="rgba(0,0,0,0.22)" strokeWidth={1.4} />,
      );
    }
  }
  return (
    <g opacity={b.op ?? 1}>
      <polygon points={left} fill={cL} stroke={cL} strokeWidth={1.1} strokeLinejoin="round" />
      <polygon points={right} fill={cR} stroke={cR} strokeWidth={1.1} strokeLinejoin="round" />
      <polygon points={top} fill={cT} stroke={cT} strokeWidth={1.1} strokeLinejoin="round" />
      {lines}
    </g>
  );
};

// ---------- util matematika ----------
export const clamp = (v: number, a = 0, b = 1) => Math.max(a, Math.min(b, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const easeOutBack = (p: number) => {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2);
};
export const easeInOut = (p: number) => (p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2);

export const mulberry32 = (seed: number) => {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};

const hash2 = (x: number, y: number, s: number) => {
  let h = (x * 374761393 + y * 668265263 + s * 2147483647) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
};
/** value-noise halus 0..1 */
export const vnoise = (x: number, y: number, s = 1) => {
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const xf = x - xi;
  const yf = y - yi;
  const u = xf * xf * (3 - 2 * xf);
  const v = yf * yf * (3 - 2 * yf);
  const a = hash2(xi, yi, s);
  const b = hash2(xi + 1, yi, s);
  const c = hash2(xi, yi + 1, s);
  const d = hash2(xi + 1, yi + 1, s);
  return lerp(lerp(a, b, u), lerp(c, d, u), v);
};
