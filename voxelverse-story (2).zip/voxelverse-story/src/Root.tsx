import React from 'react';
import {CalculateMetadataFunction, Composition, staticFile} from 'remotion';
import {Story, StoryProps} from './Story';
import {Timeline} from './types';

const fallback: Timeline = {
  fps: 30, duration: 10, hasCaptions: false, words: [], chunks: [], beats: [], envFps: 30, env: [0],
  scenes: [{s: 0, e: 10, theme: 'dawn'}],
};

// durasi video = durasi voice over (dibaca dari public/timeline.json)
const calculateMetadata: CalculateMetadataFunction<StoryProps> = async () => {
  const res = await fetch(staticFile('timeline.json'));
  const timeline = (await res.json()) as Timeline;
  return {
    durationInFrames: Math.max(1, Math.ceil(timeline.duration * timeline.fps)),
    fps: timeline.fps,
    props: {timeline},
  };
};

export const Root: React.FC = () => (
  <Composition
    id="VoxelStory"
    component={Story}
    width={1080}
    height={1920}
    fps={30}
    durationInFrames={300}
    defaultProps={{timeline: fallback}}
    calculateMetadata={calculateMetadata}
  />
);
