import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {Captions} from './Captions';
import {SceneShell} from './scenes/SceneShell';
import {Timeline} from './types';

export type StoryProps = {timeline: Timeline};

const FADE = 14; // frame cross-fade antar adegan

export const Story: React.FC<StoryProps> = ({timeline}) => {
  const {fps, scenes} = timeline;
  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      <Audio src={staticFile('voiceover.mp3')} />
      {scenes.map((sc, i) => {
        const from = Math.round(sc.s * fps);
        const end = Math.round(sc.e * fps);
        const last = i === scenes.length - 1;
        const dur = end - from + (last ? 0 : FADE);
        return (
          <Sequence key={i} from={from} durationInFrames={Math.max(1, dur)}>
            <SceneShell
              theme={sc.theme}
              sceneStart={sc.s}
              sceneEnd={sc.e}
              timeline={timeline}
              seed={11 + i * 7}
              fadeFrames={i === 0 ? 0 : FADE}
            />
          </Sequence>
        );
      })}
      <Captions timeline={timeline} />
    </AbsoluteFill>
  );
};
