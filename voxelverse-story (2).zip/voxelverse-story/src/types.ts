export type ThemeId = 'dawn' | 'forest' | 'village' | 'farm' | 'rain' | 'mountain' | 'beach' | 'night';

export type Word = {t: string; s: number; e: number};
/** potongan subtitle: kata [a, b) */
export type Chunk = {s: number; e: number; a: number; b: number};
export type SceneDef = {s: number; e: number; theme: ThemeId};

export type Timeline = {
  fps: number;
  duration: number;
  hasCaptions: boolean;
  words: Word[];
  chunks: Chunk[];
  scenes: SceneDef[];
  beats: number[];
  envFps: number;
  env: number[];
};
