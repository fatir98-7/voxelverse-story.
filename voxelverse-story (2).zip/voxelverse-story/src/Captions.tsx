import React from 'react';
import {getRemotionEnvironment, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont} from '@remotion/google-fonts/Montserrat';
import {Timeline} from './types';

const {fontFamily} = loadFont('normal', {weights: ['800', '900'], subsets: ['latin']});

const HILITE = '#FFD60A';
// outline tebal membulat (lebih rapi daripada -webkit-text-stroke yang meruncing)
const OUTLINE = (() => {
  const r = 8;
  const parts: string[] = [];
  for (let i = 0; i < 20; i++) {
    const a = (i / 20) * Math.PI * 2;
    parts.push(`${(Math.cos(a) * r).toFixed(1)}px ${(Math.sin(a) * r).toFixed(1)}px 0 #0b0b12`);
  }
  parts.push('0 12px 0 rgba(0,0,0,0.5)');
  return parts.join(',');
})();

/** Subtitle gaya TikTok/Reels: 3-5 kata, kata yang sedang diucapkan menyala kuning + membesar. */
export const Captions: React.FC<{timeline: Timeline}> = ({timeline}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;

  if (!timeline.hasCaptions) {
    if (!getRemotionEnvironment().isStudio) return null;
    return (
      <div style={{position: 'absolute', left: 60, right: 60, top: 1330, textAlign: 'center', fontFamily, fontWeight: 800, fontSize: 38, color: '#fff', background: 'rgba(0,0,0,0.55)', padding: '18px 24px', borderRadius: 18}}>
        Subtitle belum dibuat. Jalankan <b>npm run transcribe</b> atau isi <b>public/naskah.txt</b> lalu <b>npm run sync</b>.
      </div>
    );
  }

  const chunk = timeline.chunks.find((c) => t >= c.s && t < c.e);
  if (!chunk) return null;

  const words = timeline.words.slice(chunk.a, chunk.b);
  let active = 0;
  words.forEach((w, i) => {
    if (t >= w.s - 0.02) active = i;
  });

  const startFrame = Math.round(chunk.s * fps);
  const enter = spring({frame: frame - startFrame, fps, config: {damping: 13, stiffness: 240, mass: 0.6}, durationInFrames: 10});
  const exitFade = Math.min(1, Math.max(0, (chunk.e - t) / 0.06));

  return (
    <div
      style={{
        position: 'absolute', left: 50, right: 50, top: 1270, height: 330,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        opacity: exitFade,
      }}
    >
      <div
        style={{
          display: 'flex', flexWrap: 'wrap', justifyContent: 'center', alignItems: 'center',
          columnGap: 22, rowGap: 6, maxWidth: 980,
          transform: `translateY(${(1 - enter) * 26}px) scale(${0.82 + enter * 0.18})`,
          fontFamily, fontWeight: 900, fontSize: 84, lineHeight: 1.12, textTransform: 'uppercase',
          letterSpacing: -1, textAlign: 'center',
        }}
      >
        {words.map((w, i) => {
          const on = i === active;
          const wf = Math.round(w.s * fps);
          const pop = on ? spring({frame: frame - wf, fps, config: {damping: 9, stiffness: 300, mass: 0.5}, durationInFrames: 9}) : 1;
          return (
            <span
              key={`${chunk.a}-${i}`}
              style={{
                color: on ? HILITE : '#ffffff',
                textShadow: OUTLINE,
                display: 'inline-block',
                transform: on ? `scale(${1 + 0.14 * pop}) rotate(${(1 - pop) * -2}deg)` : 'none',
              }}
            >
              {w.t}
            </span>
          );
        })}
      </div>
    </div>
  );
};
