// Membangun public/timeline.json dari voiceover.mp3:
//  - jeda bicara (ffmpeg silencedetect)  -> batas adegan
//  - envelope amplitudo (30 fps)         -> animasi bereaksi pada suara
//  - kata + timestamp                    -> subtitle (3-5 kata/potongan, highlight kata aktif)
//
// Sumber teks (urutan prioritas):
//   1) public/whisper.json   (npm run transcribe)  -> timestamp kata paling akurat
//   2) public/naskah.txt     (tempel naskah Anda)  -> disejajarkan dengan jeda bicara
//   Jika keduanya ada: teks dari naskah.txt, waktu dari whisper.json.
import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';

const ROOT = process.cwd();
const PUB = path.join(ROOT, 'public');
const AUDIO = path.join(PUB, 'voiceover.mp3');
const FPS = 30;
const MAX_WORDS = 5;
const SCENE_MIN = 7.5; // detik, target panjang adegan minimum
const SCENE_PAUSE = 0.7; // jeda minimal untuk dianggap batas kalimat/adegan

// urutan "alur cerita": pembuka & penutup = fajar, adegan tengah berputar
const MID_THEMES = ['forest', 'village', 'farm', 'rain', 'mountain', 'beach', 'night'];

const r2 = (n) => Math.round(n * 100) / 100;
const r3 = (n) => Math.round(n * 1000) / 1000;

function ffmpeg(args, opts = {}) {
  let res = spawnSync('ffmpeg', args, {maxBuffer: 1 << 28, ...opts});
  if (res.error) {
    res = spawnSync('npx', ['remotion', 'ffmpeg', ...args], {
      maxBuffer: 1 << 28,
      shell: process.platform === 'win32',
      ...opts,
    });
  }
  return res;
}

// ---------- 1. durasi + jeda ----------
function analyse() {
  const res = ffmpeg(['-hide_banner', '-i', AUDIO, '-af', 'silencedetect=noise=-35dB:d=0.25', '-f', 'null', '-']);
  const log = String(res.stderr);
  const dm = log.match(/Duration:\s*(\d+):(\d+):(\d+\.\d+)/);
  if (!dm) throw new Error('Tidak bisa membaca durasi audio.');
  const duration = +dm[1] * 3600 + +dm[2] * 60 + +dm[3];
  const silences = [];
  let cur = null;
  for (const line of log.split('\n')) {
    const a = line.match(/silence_start:\s*(-?[\d.]+)/);
    const b = line.match(/silence_end:\s*([\d.]+)\s*\|\s*silence_duration:\s*([\d.]+)/);
    if (a) cur = Math.max(0, +a[1]);
    if (b && cur !== null) {
      silences.push({s: cur, e: +b[1], d: +b[2]});
      cur = null;
    }
  }
  if (cur !== null) silences.push({s: cur, e: duration, d: duration - cur});
  return {duration, silences};
}

function speechFrom(silences, duration, minPause) {
  const sil = silences.filter((x) => x.d >= minPause);
  const segs = [];
  let t = 0;
  for (const x of sil) {
    if (x.s - t > 0.08) segs.push({s: t, e: x.s});
    t = x.e;
  }
  if (duration - t > 0.08) segs.push({s: t, e: duration});
  return segs;
}

// ---------- 2. envelope amplitudo ----------
function envelope(duration) {
  const SR = 8000;
  const res = ffmpeg(['-v', 'error', '-i', AUDIO, '-ac', '1', '-ar', String(SR), '-f', 's16le', '-']);
  const buf = res.stdout;
  const n = Math.floor(duration * FPS) + 1;
  const spf = SR / FPS;
  const env = new Array(n).fill(0);
  for (let f = 0; f < n; f++) {
    let sum = 0;
    let c = 0;
    const a = Math.floor(f * spf);
    const b = Math.min(Math.floor((f + 1) * spf), Math.floor(buf.length / 2));
    for (let i = a; i < b; i++) {
      const v = buf.readInt16LE(i * 2) / 32768;
      sum += v * v;
      c++;
    }
    env[f] = c ? Math.sqrt(sum / c) : 0;
  }
  const sorted = [...env].sort((x, y) => x - y);
  const p95 = sorted[Math.floor(sorted.length * 0.95)] || 1;
  const norm = env.map((v) => Math.min(1, v / p95));
  // haluskan (attack cepat, release lambat) supaya animasi tidak bergetar
  const out = [];
  let prev = 0;
  for (const v of norm) {
    prev = v > prev ? prev + (v - prev) * 0.6 : prev + (v - prev) * 0.18;
    out.push(r2(prev));
  }
  return out;
}

// ---------- 3. kata ----------
function wordsFromWhisper(file) {
  const {captions} = JSON.parse(fs.readFileSync(file, 'utf8'));
  const words = [];
  let cur = null;
  for (const c of captions) {
    const raw = String(c.text ?? '');
    if (!raw.trim() || /^\[_.*_\]$/.test(raw.trim())) continue;
    const startsNew = /^\s/.test(raw) || !cur;
    if (startsNew) {
      if (cur) words.push(cur);
      cur = {t: raw.trim(), s: c.startMs / 1000, e: c.endMs / 1000};
    } else {
      cur.t += raw.trim();
      cur.e = c.endMs / 1000;
    }
  }
  if (cur) words.push(cur);
  return words.map((w) => ({t: w.t, s: r3(w.s), e: r3(w.e)}));
}

const weight = (w) => w.length + 1 + (/[,;:]$/.test(w) ? 2 : /[.!?…]$/.test(w) ? 4 : 0);

function alignNaskah(text, silences, duration) {
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const toWords = (s) => s.split(/\s+/).filter(Boolean);

  // a) jumlah baris naskah == jumlah segmen bicara -> 1 baris = 1 segmen (paling presisi)
  for (const th of [0.7, 0.5, 0.35, 0.25, 1.0]) {
    const segs = speechFrom(silences, duration, th);
    if (segs.length === lines.length && lines.length > 1) {
      console.log(`Naskah: ${lines.length} baris cocok dengan ${segs.length} segmen bicara (jeda >= ${th}s).`);
      const out = [];
      lines.forEach((ln, i) => {
        const ws = toWords(ln);
        const tot = ws.reduce((a, w) => a + weight(w), 0);
        let acc = 0;
        for (const w of ws) {
          const a = segs[i].s + ((segs[i].e - segs[i].s) * acc) / tot;
          acc += weight(w);
          const b = segs[i].s + ((segs[i].e - segs[i].s) * acc) / tot;
          out.push({t: w, s: r3(a), e: r3(b - 0.02)});
        }
      });
      return out;
    }
  }

  // b) distribusi proporsional di sumbu "waktu bicara" (jeda dilompati)
  console.log('Naskah: disejajarkan proporsional terhadap waktu bicara (perkiraan).');
  const segs = speechFrom(silences, duration, 0.25);
  const total = segs.reduce((a, s) => a + (s.e - s.s), 0);
  const map = (u) => {
    let rest = u;
    for (const s of segs) {
      const L = s.e - s.s;
      if (rest <= L) return s.s + rest;
      rest -= L;
    }
    return segs[segs.length - 1].e;
  };
  const ws = toWords(lines.join(' '));
  const tot = ws.reduce((a, w) => a + weight(w), 0);
  let acc = 0;
  return ws.map((w) => {
    const a = map((acc / tot) * total);
    acc += weight(w);
    const b = map((acc / tot) * total);
    return {t: w, s: r3(a), e: r3(Math.max(a + 0.08, b - 0.02))};
  });
}

function retimeWithWhisper(naskahWords, whisperWords) {
  const N = naskahWords.length;
  const M = whisperWords.length;
  if (!M) return naskahWords;
  if (N === M) return naskahWords.map((t, i) => ({t, s: whisperWords[i].s, e: whisperWords[i].e}));
  const at = (f, key) => {
    const x = Math.min(M - 1, Math.max(0, f));
    const i = Math.floor(x);
    const j = Math.min(M - 1, i + 1);
    return whisperWords[i][key] + (whisperWords[j][key] - whisperWords[i][key]) * (x - i);
  };
  return naskahWords.map((t, i) => {
    const f0 = (i / N) * M;
    const f1 = ((i + 1) / N) * M;
    return {t, s: r3(at(f0, 's')), e: r3(Math.max(at(f0, 's') + 0.08, at(f1 - 1, 'e')))};
  });
}

// ---------- 4. potongan subtitle (3-5 kata) ----------
function makeChunks(words) {
  const chunks = [];
  let i = 0;
  const groups = [];
  let start = 0;
  for (i = 0; i < words.length; i++) {
    const w = words[i];
    const next = words[i + 1];
    const punct = /[,.;:!?…]$/.test(w.t);
    const gap = next ? next.s - w.e : 99;
    if (!next || punct || gap > 0.45) {
      groups.push([start, i + 1]);
      start = i + 1;
    }
  }
  for (const [a, b] of groups) {
    const n = b - a;
    const k = Math.ceil(n / MAX_WORDS);
    const base = Math.floor(n / k);
    let extra = n % k;
    let p = a;
    for (let j = 0; j < k; j++) {
      const size = base + (extra-- > 0 ? 1 : 0);
      chunks.push({a: p, b: p + size});
      p += size;
    }
  }
  return chunks.map((c, idx) => {
    const s = words[c.a].s;
    const nextS = chunks[idx + 1] ? words[chunks[idx + 1].a].s : Infinity;
    const e = Math.min(words[c.b - 1].e + 0.18, nextS - 0.04);
    return {s: r3(Math.max(0, s - 0.04)), e: r3(e), a: c.a, b: c.b};
  });
}

// ---------- 5. adegan ----------
function makeScenes(silences, duration) {
  const cuts = silences.filter((x) => x.d >= SCENE_PAUSE).map((x) => (x.s + x.e) / 2);
  const bounds = [0];
  for (const c of cuts) {
    if (c - bounds[bounds.length - 1] >= SCENE_MIN && duration - c >= 4) bounds.push(c);
  }
  bounds.push(duration);
  const scenes = [];
  const n = bounds.length - 1;
  for (let i = 0; i < n; i++) {
    const theme = i === 0 || (i === n - 1 && n > 1) ? 'dawn' : MID_THEMES[(i - 1) % MID_THEMES.length];
    scenes.push({s: r3(bounds[i]), e: r3(bounds[i + 1]), theme});
  }
  return scenes;
}

// ---------- main ----------
const {duration, silences} = analyse();
const env = envelope(duration);

let words = [];
let source = 'tidak ada';
const whisperFile = path.join(PUB, 'whisper.json');
const naskahFile = path.join(PUB, 'naskah.txt');
const naskah = fs.existsSync(naskahFile) ? fs.readFileSync(naskahFile, 'utf8').replace(/^#.*$/gm, '').trim() : '';
const whisperWords = fs.existsSync(whisperFile) ? wordsFromWhisper(whisperFile) : [];

if (naskah) {
  const aligned = alignNaskah(naskah, silences, duration);
  words = whisperWords.length ? retimeWithWhisper(aligned.map((w) => w.t), whisperWords) : aligned;
  source = whisperWords.length ? 'naskah.txt + waktu whisper.json' : 'naskah.txt (selaras jeda)';
} else if (whisperWords.length) {
  words = whisperWords;
  source = 'whisper.json';
}

const chunks = makeChunks(words);
const speech = speechFrom(silences, duration, 0.25);
const beats = (chunks.length ? chunks.map((c) => c.s) : speech.map((s) => s.s)).map(r2);
const scenes = makeScenes(silences, duration);

const timeline = {
  fps: FPS,
  duration: r3(duration),
  hasCaptions: words.length > 0,
  words,
  chunks,
  scenes,
  beats,
  envFps: FPS,
  env,
};
fs.writeFileSync(path.join(PUB, 'timeline.json'), JSON.stringify(timeline));

console.log(`Durasi      : ${duration.toFixed(2)} dtk (${Math.ceil(duration * FPS)} frame @ ${FPS}fps)`);
console.log(`Adegan      : ${scenes.length}  ->  ${scenes.map((s) => `${s.s.toFixed(1)}s ${s.theme}`).join(' | ')}`);
console.log(`Subtitle    : ${words.length} kata / ${chunks.length} potongan  (sumber: ${source})`);
if (!words.length) {
  console.log('\n>> Subtitle belum ada. Jalankan "npm run transcribe" ATAU isi public/naskah.txt lalu "npm run sync".');
}
