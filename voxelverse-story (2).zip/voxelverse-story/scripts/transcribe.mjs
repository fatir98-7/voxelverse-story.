// Transkripsi otomatis voice over (bahasa Indonesia) dengan whisper.cpp lewat Remotion.
// Hasil: public/whisper.json (token + timestamp). Jalankan: npm run transcribe
import path from 'node:path';
import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {
  installWhisperCpp,
  downloadWhisperModel,
  transcribe,
  toCaptions,
} from '@remotion/install-whisper-cpp';

const ROOT = process.cwd();
const AUDIO = path.join(ROOT, 'public', 'voiceover.mp3');
const TMP = path.join(ROOT, '.whisper-tmp');
const WAV = path.join(TMP, 'voiceover-16k.wav');
const WHISPER_DIR = path.join(ROOT, 'whisper.cpp');
const VERSION = '1.5.5';
const MODEL = process.env.WHISPER_MODEL || 'medium'; // 'small' = lebih ringan, 'medium' = lebih akurat

fs.mkdirSync(TMP, {recursive: true});

console.log('1/4  Konversi audio ke WAV 16 kHz ...');
const ff = spawnSync(
  'npx',
  ['remotion', 'ffmpeg', '-i', AUDIO, '-ar', '16000', '-ac', '1', WAV, '-y'],
  {stdio: 'inherit', shell: process.platform === 'win32'},
);
if (ff.status !== 0) throw new Error('Konversi audio gagal.');

console.log('2/4  Menyiapkan whisper.cpp (sekali saja) ...');
await installWhisperCpp({to: WHISPER_DIR, version: VERSION});

console.log(`3/4  Mengunduh model "${MODEL}" (sekali saja) ...`);
await downloadWhisperModel({model: MODEL, folder: WHISPER_DIR});

console.log('4/4  Transkripsi (bahasa Indonesia) ...');
const output = await transcribe({
  model: MODEL,
  whisperPath: WHISPER_DIR,
  whisperCppVersion: VERSION,
  inputPath: WAV,
  language: 'id',
  tokenLevelTimestamps: true,
});

const {captions} = toCaptions({whisperCppOutput: output});
fs.writeFileSync(
  path.join(ROOT, 'public', 'whisper.json'),
  JSON.stringify({captions}, null, 1),
);
console.log(`Selesai: public/whisper.json (${captions.length} token)`);
