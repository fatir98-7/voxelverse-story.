# VOXELVERSE Story — Remotion 9:16 (1080×1920, 30 fps)

Animasi cerita bergaya voxel isometrik, disinkronkan dengan `public/voiceover.mp3` (91 dtk = 2731 frame).

## Mulai cepat
```bash
npm install
npm run transcribe   # sekali: transkripsi otomatis (bahasa Indonesia) -> subtitle + timeline
npm run studio       # pratinjau
npm run render       # hasil: out/voxelverse-story.mp4
```
`npm run transcribe` memakai whisper.cpp (unduhan awal ±1,5 GB untuk model `medium`;
pakai `WHISPER_MODEL=small npm run transcribe` untuk yang lebih ringan).

## Tanpa transkripsi: pakai naskah sendiri
1. Tempel naskah di `public/naskah.txt` (satu kalimat per baris; baris berawalan `#` diabaikan).
2. `npm run sync`.
Jika jumlah baris = jumlah segmen bicara, tiap baris dipetakan tepat ke satu segmen; jika tidak, kata
didistribusikan proporsional terhadap waktu bicara (jeda dilewati). Jika `whisper.json` dan `naskah.txt`
sama-sama ada: teks dari naskah, waktu dari whisper.

## Bagaimana sinkronisasinya
`scripts/build-timeline.mjs` membaca audio dan menulis `public/timeline.json`:
- **Adegan** dipotong di tengah jeda bicara ≥ 0,7 dtk (panjang ≥ 7,5 dtk) → pergantian visual jatuh di jeda napas.
- **Envelope amplitudo** 30 fps → cahaya, asap, api, kubus melayang, dan zoom kamera berdenyut mengikuti suara.
- **Beats** (awal tiap potongan subtitle) → kamera "menyentak" halus tiap frasa baru.
- **Subtitle**: maks. 5 kata/potongan (dipecah di tanda baca / jeda, ukuran dibuat seimbang),
  kata yang sedang diucapkan menyala kuning + membesar.

## Kustomisasi
- Tema tiap adegan: ubah `theme` di `public/timeline.json` (`dawn forest village farm rain mountain beach night`)
  atau ubah `MID_THEMES` di `scripts/build-timeline.mjs`.
- Adegan baru / ubah isi: `src/scenes/themes.ts` (semua dibangun dari kotak voxel lewat `Scn.box`).
- Gaya subtitle: `src/Captions.tsx` (ukuran 84px, warna highlight `HILITE`, posisi `top: 1270`).
- Subtitle diletakkan di area aman (di atas UI bawah TikTok/Reels).
